


package BubbleSort;

public class Mm {

// Driver program

  public static void main(String args[]) {
    int arr[] = { 6, 2, 16, 10, 9, 1 };

    MergeSort ob = new MergeSort();
    ob.mergeSort(arr, 0, arr.length - 1);

    System.out.println("Sorted array:");
   ob. printArray(arr);
  }

}
